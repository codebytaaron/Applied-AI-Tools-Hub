# Data Cleanup + Normalization Planner

Creates a step-by-step plan to clean a dataset export and define schema rules.

## What it does
Given a sample export description, outputs normalization rules, validation checks, and a cleanup checklist.

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# set MOCK_MODE=true to run without an API key
python main.py --in examples/input.txt --out out.md
```

## Customize
- Edit `prompt.py` to fit your rules, formatting, and required outputs.
- Add real examples to `examples/`.

## Output
- Writes a structured result to `out.md`.
