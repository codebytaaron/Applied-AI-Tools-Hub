# 15 More Business AI Workflow Models

Each folder is a standalone mini-repo.

## Included models
- **13-risk-register**: Operational Risk Register Builder - Turns messy notes into a risk register with likelihood, impact, mitigations, owners, and review cadence.
- **14-onboarding-coach**: Customer Onboarding Playbook Generator - Creates an onboarding sequence, success milestones, and a check-in schedule to reduce churn.
- **15-qa-testwriter**: QA Test Case Writer - Generates clear test cases (happy path, edge cases, regressions) from requirements or bug reports.
- **16-data-cleanup**: Data Cleanup + Normalization Planner - Creates a step-by-step plan to clean a dataset export and define schema rules.
- **17-procurement-assistant**: Procurement Comparison Assistant - Compares vendor quotes and recommends a winner based on weighted criteria.
- **18-incident-commander**: Incident Response Coordinator - Creates a timeline, root-cause hypotheses, comms plan, and postmortem outline for incidents.
- **19-training-module**: Internal Training Module Builder - Turns a topic into a training lesson with exercises, quizzes, and a competency checklist.
- **20-partnership-evaluator**: Partnership Fit Evaluator - Scores partnership opportunities and drafts a one-page deal brief.
- **21-pricing-experimenter**: Pricing Experiment Designer - Designs pricing tests with hypotheses, segments, success metrics, and guardrails.
- **22-ux-research-synth**: UX Research Synthesizer - Synthesizes interview notes into themes, user needs, and prioritized improvements.
- **23-change-management**: Change Management Planner - Builds a rollout plan for process/tool changes with comms, training, and adoption metrics.
- **24-security-reviewer**: Security Review Checklist Builder - Creates a security review checklist and threat model notes for a feature.
- **25-finops-optimizer**: Cloud Cost Optimization Planner - Turns cloud billing summaries into cost-saving actions with estimated impact.
- **26-customer-voice**: Voice of Customer Extractor - Extracts product insights from reviews/tickets and proposes roadmap items.
- **27-supplier-forecast**: Supplier Lead-Time Forecaster - Builds a simple lead-time forecast and buffer strategy to prevent stockouts.

## Run
```bash
cd 13-risk-register
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python main.py --in examples/input.txt --out out.md
```
