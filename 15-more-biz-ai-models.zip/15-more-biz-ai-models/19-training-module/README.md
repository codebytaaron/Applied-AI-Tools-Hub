# Internal Training Module Builder

Turns a topic into a training lesson with exercises, quizzes, and a competency checklist.

## What it does
Given a role and topic, outputs a short module, practice scenarios, quiz questions, and a rubric.

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# set MOCK_MODE=true to run without an API key
python main.py --in examples/input.txt --out out.md
```

## Customize
- Edit `prompt.py` to fit your rules, formatting, and required outputs.
- Add real examples to `examples/`.

## Output
- Writes a structured result to `out.md`.
